import { useEffect, useState } from 'react';
import { workOrderService } from '../../../services/workOrderService';
import { Button } from '../../../components/ui/button';
import { Input } from '../../../components/ui/input';
import { Textarea } from '../../../components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '../../../components/ui/dialog';
import { Label } from '../../../components/ui/label';
import { Plus, Trash2, CalendarClock, AlertCircle } from 'lucide-react';
import type { Database } from '../../../types/supabase';

type Pianificazione = Database['public']['Tables']['pianificazioni']['Row'];

interface PlanningManagerProps {
    workOrderId: string;
    status: string;
}

export function PlanningManager({ workOrderId, status }: PlanningManagerProps) {
    const [plannings, setPlannings] = useState<Pianificazione[]>([]);
    // Modal State
    const [open, setOpen] = useState(false);
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [date, setDate] = useState('');
    const [noteImportanti, setNoteImportanti] = useState('');
    const [noteChiusura, setNoteChiusura] = useState('');
    const [saving, setSaving] = useState(false);

    const normalizedStatus = status?.toLowerCase().trim() || '';
    const isReadOnly = ['closed', 'completed', 'chiuso', 'completato', 'terminato', 'chiuso completato'].includes(normalizedStatus);

    useEffect(() => {
        loadPlannings();
    }, [workOrderId]);

    const loadPlannings = async () => {
        try {
            const data = await workOrderService.getPianificazioni(workOrderId);
            setPlannings(data || []);
        } catch (err) {
            console.error(err);
        }
    };

    const handleRowClick = (planning: Pianificazione) => {
        setSelectedId(planning.id);
        const d = new Date(planning.data_pianificazione);
        const formattedDate = d.toISOString().slice(0, 16);

        setDate(formattedDate);
        setNoteImportanti(planning.note_importanti || '');
        setNoteChiusura(planning.note_chiusura || '');
        setOpen(true);
    };

    const handleSave = async () => {
        if (!date) return;
        setSaving(true);
        try {
            const dateObj = new Date(date);
            const isoString = dateObj.toISOString();

            if (selectedId) {
                await workOrderService.updatePianificazione(selectedId, {
                    date: isoString,
                    noteImportanti: noteImportanti || undefined,
                    noteChiusura: noteChiusura || undefined
                });
            } else {
                await workOrderService.addPianificazione({
                    workOrderId,
                    date: isoString,
                    noteImportanti: noteImportanti || undefined,
                    noteChiusura: noteChiusura || undefined
                });
            }

            setOpen(false);
            resetForm();
            loadPlannings();
        } catch (err) {
            console.error('Failed to save planning', err);
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation(); // Prevent row click
        try {
            await workOrderService.deletePianificazione(id);
            setPlannings(prev => prev.filter(p => p.id !== id));
        } catch (err) {
            console.error('Failed to delete', err);
        }
    };

    const resetForm = () => {
        setSelectedId(null);
        setDate('');
        setNoteImportanti('');
        setNoteChiusura('');
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold flex items-center gap-2">
                    <CalendarClock className="h-4 w-4 text-primary" />
                    Elenco Pianificazioni
                </h3>
                {!isReadOnly && (
                    <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setOpen(true)}>
                        <Plus className="h-4 w-4" />
                    </Button>
                )}
            </div>

            {/* List */}
            <div className="rounded-md border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 overflow-hidden">
                <table className="w-full text-sm">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-left">
                        <tr>
                            <th className="p-2 font-medium text-muted-foreground w-1/3">Data</th>
                            <th className="p-2 font-medium text-muted-foreground">Note</th>
                            <th className="p-2 w-[50px]"></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                        {plannings.length === 0 ? (
                            <tr>
                                <td colSpan={3} className="p-4 text-center text-muted-foreground italic">
                                    Nessuna pianificazione inserita.
                                </td>
                            </tr>
                        ) : (
                            plannings.map(p => (
                                <tr
                                    key={p.id}
                                    className="group hover:bg-white dark:hover:bg-slate-900 transition-colors cursor-pointer"
                                    onClick={() => handleRowClick(p)}
                                >
                                    <td className="p-2 font-medium align-top">
                                        {new Date(p.data_pianificazione).toLocaleString('it-IT', {
                                            day: '2-digit', month: '2-digit', year: 'numeric',
                                            hour: '2-digit', minute: '2-digit'
                                        })}
                                    </td>
                                    <td className="p-2 text-xs align-top">
                                        {(p.note_importanti || p.note_chiusura) ? (
                                            <div className="space-y-1">
                                                {p.note_importanti && (
                                                    <div className="flex gap-1 text-amber-600 dark:text-amber-500">
                                                        <AlertCircle className="h-3 w-3 mt-0.5 shrink-0" />
                                                        <span>{p.note_importanti}</span>
                                                    </div>
                                                )}
                                                {p.note_chiusura && (
                                                    <div className="text-slate-500">
                                                        <span className="font-semibold">Chiusura:</span> {p.note_chiusura}
                                                    </div>
                                                )}
                                            </div>
                                        ) : (
                                            <span className="text-slate-400 italic">-</span>
                                        )}
                                    </td>
                                    <td className="p-2 text-right align-top">
                                        {!isReadOnly && (
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-6 w-6 p-0 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                                                onClick={(e) => handleDelete(p.id, e)}
                                            >
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        )}
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Add/Edit Modal */}
            <Dialog open={open} onOpenChange={(val) => {
                if (!val) resetForm();
                setOpen(val);
            }}>
                <DialogContent className="sm:max-w-[550px] p-0 overflow-hidden gap-0">
                    <DialogHeader className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                        <DialogTitle className="text-lg">
                            {selectedId ? "Dettagli Pianificazione" : "Nuova Pianificazione"}
                        </DialogTitle>
                        <DialogDescription>
                            {selectedId ? "Visualizza o modifica i dettagli della pianificazione." : "Inserisci i dettagli per la nuova pianificazione tecnica."}
                        </DialogDescription>
                    </DialogHeader>

                    <div className="p-6 space-y-5">
                        <fieldset disabled={isReadOnly} className="space-y-5 group-disabled:opacity-50">
                            <div className="space-y-2">
                                <Label htmlFor="date" className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                                    Data Pianificazione <span className="text-red-500">*</span>
                                </Label>
                                <Input
                                    id="date"
                                    type="datetime-local"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                    className="font-mono disabled:opacity-50"
                                    disabled={isReadOnly}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="note" className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                                    Note Importanti
                                </Label>
                                <Textarea
                                    id="note"
                                    placeholder="Inserisci informazioni critiche per l'intervento..."
                                    value={noteImportanti}
                                    onChange={(e) => setNoteImportanti(e.target.value)}
                                    className="min-h-[80px] resize-none disabled:opacity-50"
                                    disabled={isReadOnly}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label htmlFor="chiusura" className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                                    Note Chiusura
                                </Label>
                                <Textarea
                                    id="chiusura"
                                    placeholder="Eventuali note relative alla chiusura prevista..."
                                    value={noteChiusura}
                                    onChange={(e) => setNoteChiusura(e.target.value)}
                                    className="min-h-[80px] resize-none disabled:opacity-50"
                                    disabled={isReadOnly}
                                />
                            </div>
                        </fieldset>
                    </div>

                    <DialogFooter className="px-6 py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50 gap-2">
                        <Button variant="outline" onClick={() => setOpen(false)}>Chiudi</Button>
                        {!isReadOnly && (
                            <Button onClick={handleSave} disabled={!date || saving}>
                                {saving ? "Salvataggio..." : "Salva Pianificazione"}
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
