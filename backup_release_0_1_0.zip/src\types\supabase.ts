export type Json =
    | string
    | number
    | boolean
    | null
    | { [key: string]: Json | undefined }
    | Json[]

export interface Database {
    public: {
        Tables: {
            profiles: {
                Row: {
                    id: string
                    email: string
                    role: 'admin' | 'supervisor' | 'project_manager' | 'operator'
                    full_name: string | null
                    created_at: string | null
                    updated_at: string | null
                }
                Insert: {
                    id: string
                    email: string
                    role: 'admin' | 'supervisor' | 'project_manager' | 'operator'
                    full_name?: string | null
                    created_at?: string | null
                    updated_at?: string | null
                }
                Update: {
                    id?: string
                    email?: string
                    role?: 'admin' | 'supervisor' | 'project_manager' | 'operator'
                    full_name?: string | null
                    created_at?: string | null
                    updated_at?: string | null
                }
            }
            pianificazioni: {
                Row: {
                    id: string
                    work_order_id: string
                    data_pianificazione: string
                    note_importanti: string | null
                    note_chiusura: string | null
                    esito: 'OK' | 'NON OK' | null
                    created_at: string | null
                }
                Insert: {
                    id?: string
                    work_order_id: string
                    data_pianificazione: string
                    note_importanti?: string | null
                    note_chiusura?: string | null
                    esito?: 'OK' | 'NON OK' | null
                    created_at?: string | null
                }
                Update: {
                    id?: string
                    work_order_id?: string
                    data_pianificazione?: string
                    note_importanti?: string | null
                    note_chiusura?: string | null
                    esito?: 'OK' | 'NON OK' | null
                    created_at?: string | null
                }
            }
            work_orders: {
                Row: {
                    work_order: string
                    numero: string | null
                    progetto: string | null
                    soa_code: string | null
                    breve_descrizione: string | null
                    descrizione: string | null
                    stato: string
                    avvio_programmato: string | null
                    fine_prevista: string | null
                    aggiornato: string | null
                    chiuso: string | null
                    regione: string | null
                    citta: string | null
                    provincia: string | null
                    cap: string | null
                    via: string | null
                    telefono: string | null
                    sede_presidiata: boolean | null
                    created_by: string | null
                    system_created_at: string | null
                    system_updated_at: string | null
                }
                Insert: {
                    work_order: string
                    numero?: string | null
                    progetto?: string | null
                    soa_code?: string | null
                    breve_descrizione?: string | null
                    descrizione?: string | null
                    stato?: string
                    avvio_programmato?: string | null
                    fine_prevista?: string | null
                    aggiornato?: string | null
                    chiuso?: string | null
                    regione?: string | null
                    citta?: string | null
                    provincia?: string | null
                    cap?: string | null
                    via?: string | null
                    telefono?: string | null
                    sede_presidiata?: boolean | null
                    created_by?: string | null
                    system_created_at?: string | null
                    system_updated_at?: string | null
                }
                Update: {
                    work_order?: string
                    numero?: string | null
                    progetto?: string | null
                    soa_code?: string | null
                    breve_descrizione?: string | null
                    descrizione?: string | null
                    stato?: string
                    avvio_programmato?: string | null
                    fine_prevista?: string | null
                    aggiornato?: string | null
                    chiuso?: string | null
                    regione?: string | null
                    citta?: string | null
                    provincia?: string | null
                    cap?: string | null
                    via?: string | null
                    telefono?: string | null
                    sede_presidiata?: boolean | null
                    created_by?: string | null
                    system_created_at?: string | null
                    system_updated_at?: string | null
                }
            }
        }
        Views: {
            [_ in never]: never
        }
        Functions: {
            get_current_user_role: {
                Args: Record<PropertyKey, never>
                Returns: string
            }
        }
        Enums: {
            [_ in never]: never
        }
    }
}
