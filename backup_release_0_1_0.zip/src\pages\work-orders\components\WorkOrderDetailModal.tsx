import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '../../../components/ui/dialog';
import { Button } from '../../../components/ui/button';
import { Label } from '../../../components/ui/label';
import { Calendar, MapPin, ClipboardList, Phone, Building2, CheckCircle2 } from 'lucide-react';
import { cn } from '../../../utils/cn';
import type { WorkOrder } from '../../../services/workOrderService';
import { PlanningManager } from './PlanningManager';

interface WorkOrderDetailModalProps {
    workOrder: WorkOrder | null;
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

export function WorkOrderDetailModal({ workOrder, open, onOpenChange }: WorkOrderDetailModalProps) {
    if (!workOrder) return null;

    // Styling helpers
    const InfoCard = ({ icon: Icon, label, value, className }: any) => (
        <div className={cn("flex items-start p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 transition-all hover:bg-white hover:shadow-md", className)}>
            <div className="p-2 rounded-lg bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-800 mr-3 shrink-0 shadow-sm">
                <Icon className="h-4 w-4 text-primary" />
            </div>
            <div>
                <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-1">{label}</p>
                <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 font-mono tracking-tight">{value || '-'}</p>
            </div>
        </div>
    );

    const fullAddress = [workOrder.via, workOrder.cap, workOrder.citta, `(${workOrder.provincia})`].filter(Boolean).join(' ');

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-[85vw] w-[85vw] h-[85vh] max-h-[85vh] flex flex-col p-0 overflow-hidden outline-none">

                {/* Header */}
                <DialogHeader className="px-8 py-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 backdrop-blur-sm shrink-0">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <div>
                                <DialogTitle className="text-2xl font-bold text-slate-900">Work Order {workOrder.work_order}</DialogTitle>
                                <DialogDescription className="flex items-center gap-2 mt-1 text-base">
                                    <MapPin className="h-4 w-4 text-slate-400" /> {workOrder.citta} &bull; <span className="text-slate-500 font-medium">{workOrder.progetto}</span>
                                </DialogDescription>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <div className={cn(
                                "px-4 py-1.5 rounded-full text-sm font-semibold border shadow-sm",
                                workOrder.stato === 'New' ? "bg-blue-50 text-blue-700 border-blue-200" :
                                    workOrder.stato === 'In Progress' ? "bg-amber-50 text-amber-700 border-amber-200" :
                                        "bg-green-50 text-green-700 border-green-200"
                            )}>
                                {workOrder.stato}
                            </div>
                        </div>
                    </div>
                </DialogHeader>

                {/* Scrollable Content */}
                <div className="flex-1 overflow-y-auto p-8 bg-white dark:bg-slate-950">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                        {/* Left Column: Registry & Info */}
                        <div className="space-y-8 lg:col-span-1">

                            {/* Anagrafica Section */}
                            <section>
                                <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                                    <Building2 className="h-5 w-5 text-slate-400" /> Anagrafica & Sede
                                </h3>
                                <div className="space-y-3">
                                    <InfoCard icon={MapPin} label="Indirizzo Completo" value={fullAddress} />
                                    <InfoCard icon={MapPin} label="Regione" value={workOrder.regione} />
                                    <InfoCard icon={Phone} label="Recapito Telefonico" value={workOrder.telefono} />
                                    <InfoCard
                                        icon={CheckCircle2}
                                        label="Presidio"
                                        value={workOrder.sede_presidiata ? "Sede Presidiata" : "Non Presidiata"}
                                        className={workOrder.sede_presidiata ? "border-green-200 bg-green-50/30" : ""}
                                    />
                                </div>
                            </section>

                            {/* Timeline Section */}
                            <section>
                                <h3 className="text-lg font-semibold text-slate-900 mb-6 flex items-center gap-2">
                                    <Calendar className="h-5 w-5 text-slate-400" /> Timeline
                                </h3>

                                <div className="space-y-0 relative pl-4 border-l-2 border-slate-200 dark:border-slate-800 ml-3">
                                    {[
                                        { label: 'Avvio Programmato', date: workOrder.avvio_programmato, color: 'blue' },
                                        { label: 'Scadenza Prevista', date: workOrder.fine_prevista, color: 'amber' },
                                        { label: 'Ultimo Aggiornamento', date: workOrder.aggiornato, color: 'slate' },
                                        {
                                            label: 'Chiusura',
                                            date: workOrder.chiuso,
                                            color: workOrder.chiuso && workOrder.fine_prevista && new Date(workOrder.chiuso) > new Date(workOrder.fine_prevista) ? 'red' : 'green'
                                        }
                                    ]
                                        .filter(e => e.date) // Only show existing dates
                                        .sort((a, b) => new Date(a.date!).getTime() - new Date(b.date!).getTime())
                                        .map((event, index) => (
                                            <div key={index} className="relative pb-8 pl-6 last:pb-2">
                                                <div className={cn(
                                                    "absolute -left-[31px] top-1 h-4 w-4 rounded-full border-2 border-white dark:border-slate-950",
                                                    event.color === 'blue' ? "bg-blue-500" :
                                                        event.color === 'amber' ? "bg-amber-500" :
                                                            event.color === 'green' ? "bg-green-500" :
                                                                event.color === 'red' ? "bg-red-500" :
                                                                    "bg-slate-300 dark:bg-slate-700"
                                                )} />
                                                <div className="flex flex-col">
                                                    <span className={cn(
                                                        "text-xs font-bold uppercase tracking-widest",
                                                        event.color === 'blue' ? "text-blue-600 dark:text-blue-400" :
                                                            event.color === 'amber' ? "text-amber-600 dark:text-amber-500" :
                                                                event.color === 'green' ? "text-green-600 dark:text-green-500" :
                                                                    event.color === 'red' ? "text-red-600 dark:text-red-500" :
                                                                        "text-slate-500"
                                                    )}>{event.label}</span>
                                                    <span className="text-sm font-semibold text-slate-900 dark:text-slate-100 mt-1">
                                                        {new Date(event.date!).toLocaleDateString()}
                                                    </span>
                                                </div>
                                            </div>
                                        ))}
                                </div>
                            </section>

                            {/* Planning Section of WorkOrderDetailModal */}
                            <section className="pt-6 border-t border-slate-100 dark:border-slate-800">
                                <PlanningManager workOrderId={workOrder.work_order} status={workOrder.stato} />
                            </section>

                        </div>

                        {/* Right Column: Description & Technical Context */}
                        <div className="lg:col-span-2 space-y-6">
                            <section className="h-full flex flex-col">
                                <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                                    <ClipboardList className="h-5 w-5 text-slate-400" /> Dettagli Intervento
                                </h3>
                                <div className="flex-1 p-6 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-base leading-7 text-slate-700 dark:text-slate-300 font-sans">
                                    <Label className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-2 block">Descrizione Richiesta</Label>
                                    {workOrder.descrizione || "Nessuna descrizione disponibile per questo ordine di lavoro."}

                                    {workOrder.breve_descrizione && (
                                        <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800">
                                            <Label className="text-xs text-slate-400 uppercase tracking-widest font-bold mb-2 block">Oggetto Breve</Label>
                                            <p className="font-medium">{workOrder.breve_descrizione}</p>
                                        </div>
                                    )}
                                </div>
                            </section>
                        </div>

                    </div>
                </div>

                {/* Footer */}
                <DialogFooter className="px-8 py-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 backdrop-blur-sm shrink-0">
                    <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">
                        Chiudi Scheda
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
