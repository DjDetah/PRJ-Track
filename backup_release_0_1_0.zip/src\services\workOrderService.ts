import { supabase } from './supabase';
import { type Database } from '../types/supabase';

export type WorkOrder = Database['public']['Tables']['work_orders']['Row'] & {
    pianificazioni?: { data_pianificazione: string }[];
};
export type WorkOrderInsert = Database['public']['Tables']['work_orders']['Insert'];
export type WorkOrderUpdate = Database['public']['Tables']['work_orders']['Update'];

export const workOrderService = {
    // Fetch all work orders (filtered by RLS automatically)
    async getAll() {
        const { data, error } = await supabase
            .from('work_orders')
            .select('*, pianificazioni(data_pianificazione)')
            .order('system_created_at', { ascending: false });

        if (error) throw error;
        return data;
    },

    // Get a single work order by ID (PK)
    async getById(id: string) {
        const { data, error } = await supabase
            .from('work_orders')
            .select('*')
            .eq('work_order', id)
            .single();

        if (error) throw error;
        return data;
    },

    // Create a new work order
    async create(workOrder: WorkOrderInsert) {
        const { data, error } = await supabase
            .from('work_orders')
            .insert(workOrder)
            .select()
            .single();

        if (error) throw error;
        return data;
    },

    // Create multiple work orders (Bulk Import)
    async createBulk(workOrders: WorkOrderInsert[]) {
        // Supabase allows bulk insert by passing an array
        const { data, error } = await supabase
            .from('work_orders')
            .insert(workOrders)
            .select();

        return { data, error };
    },

    // Update an existing work order
    async update(id: string, updates: WorkOrderUpdate) {
        const { data, error } = await supabase
            .from('work_orders')
            .update(updates)
            .eq('work_order', id)
            .select()
            .single();

        if (error) throw error;
        return data;
    },
    // PIANIFICAZIONI METHODS
    async getPianificazioni(workOrderId: string) {
        const { data, error } = await supabase
            .from('pianificazioni')
            .select('*')
            .eq('work_order_id', workOrderId)
            .order('data_pianificazione', { ascending: true }); // chronological order

        if (error) throw error;
        return data;
    },

    async addPianificazione(planning: {
        workOrderId: string;
        date: string;
        noteImportanti?: string;
        noteChiusura?: string;
    }) {
        const { data, error } = await supabase
            .from('pianificazioni')
            .insert({
                work_order_id: planning.workOrderId,
                data_pianificazione: planning.date,
                note_importanti: planning.noteImportanti,
                note_chiusura: planning.noteChiusura
            })
            .select()
            .single();

        if (error) throw error;
        return data;
    },

    async updatePianificazione(id: string, updates: {
        date?: string;
        noteImportanti?: string;
        noteChiusura?: string;
    }) {
        const { data, error } = await supabase
            .from('pianificazioni')
            .update({
                data_pianificazione: updates.date,
                note_importanti: updates.noteImportanti,
                note_chiusura: updates.noteChiusura
            })
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;
        return data;
    },

    async deletePianificazione(id: string) {
        const { error } = await supabase
            .from('pianificazioni')
            .delete()
            .eq('id', id);

        if (error) throw error;
    },

    async getProjectStats() {
        const { data, error } = await supabase
            .from('work_orders')
            .select('progetto, stato');

        if (error) throw error;

        // Client-side aggregation
        const statsMap = new Map<string, { total: number; closed: number; open: number }>();
        const closedStatuses = ['Closed', 'Completed', 'Chiuso', 'Completato', 'Terminato', 'chiuso completato'];

        data.forEach(row => {
            const project = row.progetto || 'Senza Progetto';
            if (!statsMap.has(project)) {
                statsMap.set(project, { total: 0, closed: 0, open: 0 });
            }

            const stat = statsMap.get(project)!;
            stat.total++;

            const isClosed = closedStatuses.some(s => s.toLowerCase() === row.stato?.toLowerCase());
            if (isClosed) {
                stat.closed++;
            } else {
                stat.open++;
            }
        });

        return Array.from(statsMap.entries()).map(([name, stats]) => ({
            name,
            ...stats
        })).sort((a, b) => b.total - a.total);
    },

    async getByProject(projectName: string) {
        if (projectName === 'Senza Progetto') {
            const { data, error } = await supabase
                .from('work_orders')
                .select('*, pianificazioni(data_pianificazione)')
                .is('progetto', null)
                .order('system_updated_at', { ascending: false });

            if (error) throw error;
            return data;
        }

        const { data, error } = await supabase
            .from('work_orders')
            .select('*, pianificazioni(data_pianificazione)')
            .eq('progetto', projectName)
            .order('system_updated_at', { ascending: false });

        if (error) throw error;
        return data;
    }
};
